package com.grace.weeclik.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.grace.weeclik.DetailsActivity;
import com.grace.weeclik.OnLoadMoreListener;
import com.grace.weeclik.R;
import com.grace.weeclik.model.Commerce;

import java.util.List;

/**
 * com.grace.weeclik.adapter
 * Created by grace on 06/05/2018.
 */
public class CommerceAdapter extends RecyclerView.Adapter {

    private final int VIEW_ITEM = 1;
    private final int VIEW_PROG = 0;

    private Context context;
    private List<Commerce> commerces;

    // Le nombre min d'elts a avoir en dessous de la position de defilement en cours
    // avant de charger plus
    private int visible_item = 8;
    private int last_visible_item, total_item_count;
    private boolean loading;

    private OnLoadMoreListener onLoadMoreListener;

    public CommerceAdapter(Context context, List<Commerce> commerces, RecyclerView recyclerView) {
        this.context = context;
        this.commerces = commerces;

        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);

                    total_item_count = linearLayoutManager.getItemCount();
                    last_visible_item = linearLayoutManager.findLastVisibleItemPosition();

                    if (! loading && total_item_count <= (last_visible_item + visible_item)) {
                        // La fin a ete atteinte
                        // Fait quelque chose
                        if (onLoadMoreListener != null) {
                            onLoadMoreListener.onLoadMore();
                        }
                        loading = true;
                    }
                }
            });
        }
    }

    @Override
    public int getItemViewType(int position) {
        return commerces.get(position) != null ? VIEW_ITEM : VIEW_PROG;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        if (viewType == VIEW_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_main, parent, false);
            viewHolder = new ViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.progressbar, parent, false);
            viewHolder = new ProgressViewHolder(view);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {
            Commerce commerce = commerces.get(position);
            ((ViewHolder) holder).name.setText(commerce.getName());
            Glide.with(context).load(commerce.getThumbnail()).into(((ViewHolder) holder).thumbnail);
        } else {
            ((ProgressViewHolder) holder).progressBar.setIndeterminate(true);
        }
    }

    /*@Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Commerce commerce = commerces.get(position);
        holder.name.setText(commerce.getName());
        Glide.with(context).load(commerce.getThumbnail()).into(holder.thumbnail);
    }*/

    @Override
    public int getItemCount() {
        return commerces.size();
    }

    public void setLoading() {
        loading = false;
    }

    public void setOnLoadMoreListener(OnLoadMoreListener onLoadMoreListener) {
        this.onLoadMoreListener = onLoadMoreListener;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        ImageView thumbnail;

        ViewHolder(View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.item_main_text_view_name);
            thumbnail = itemView.findViewById(R.id.item_main_image_view);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Intent intent = new Intent(context, DetailsActivity.class);
                    intent.putExtra("NAME_TRADE", commerces.get(getLayoutPosition()).getName());
                    intent.putExtra("IMAGE_TRADE", commerces.get(getLayoutPosition()).getThumbnail());
                    intent.putExtra("NBSHARE_TRADE", commerces.get(getLayoutPosition()).getNbShare());
                    context.startActivity(intent);
                }
            });
        }
    }



    public static class ProgressViewHolder extends RecyclerView.ViewHolder {

        public ProgressBar progressBar;

        public ProgressViewHolder(View itemView) {
            super(itemView);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }
}
