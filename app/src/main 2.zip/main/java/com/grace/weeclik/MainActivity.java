package com.grace.weeclik;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.bumptech.glide.Glide;
import com.grace.weeclik.adapter.CommerceAdapter;
import com.grace.weeclik.model.Commerce;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Commerce> commerces;
    private CommerceAdapter adapter;
    private Spinner spinner;

//    AppBarLayout appBarLayout;

    ImageButton imageButton;

    protected Handler handler;
    LinearLayout layoutEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initView();
        getActivities("Artisanat");

        // TODO What Handler
        handler = new Handler();

        imageButton = findViewById(R.id.ib_account);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
            }
        });


        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.activity_area, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
        spinner.setSelection(0);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Log.e("RRR", item);
                try {
                    Glide.with(MainActivity.this).load(changeImage(item)).into((ImageView) findViewById(R.id.bg_toolbar));
                    //Glide.with(MainActivity.this).load(changeImage(item)).into((ImageView) findViewById(R.id.bg_toolbar));
                    getActivities(item);
                    adapter = new CommerceAdapter(MainActivity.this, commerces, recyclerView);
                    recyclerView.setAdapter(adapter);
                    // TODO Loading data more
                    adapter.setOnLoadMoreListener(new OnLoadMoreListener() {
                        @Override
                        public void onLoadMore() {
                            commerces.add(null);
                            adapter.notifyItemInserted(commerces.size() - 1);

                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    // Supprime l'elt de progression
                                    commerces.remove(commerces.size() - 1);
                                    adapter.notifyItemRemoved(commerces.size());
                                    // Ajout d'elts un par un
                                    int start = commerces.size();
                                    int end = start + 20;

                                    for (int i = start + 1; i <= end; i++) {
                                        // commerces.add(new Commerce())
                                        adapter.notifyItemInserted(commerces.size());
                                    }

                                    adapter.setLoading();

                                }
                            }, 2000);
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
                getActivities(item);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
// TODO Adaptor
        adapter = new CommerceAdapter(this, commerces, recyclerView);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(), true));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        //isEmptyCommerce();

        try {
            Glide.with(MainActivity.this).load(R.drawable.cover1).into((ImageView) findViewById(R.id.bg_toolbar));
            //Glide.with(MainActivity.this).load(R.drawable.cover1).into((AppBarLayout) findViewById(R.id.app_bar_main));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void isEmptyCommerce() {
        if (commerces.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            layoutEmpty.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            layoutEmpty.setVisibility(View.GONE);
        }
    }

    private int changeImage(String item) {
        int id;
        switch (item) {
            case "Artisanat":
                id = R.drawable.cover1;
                break;
            case "Bien-être":
                id = R.drawable.cover2;
                break;
            case "Décoration":
                id = R.drawable.cover3;
                break;
            case "E-commerce":
                id = R.drawable.cover4;
                break;
            case "Distribution":
                id = R.drawable.cover5;
                break;
            case "Hôtellerie":
                id = R.drawable.cover6;
                break;
            case "Immobilier":
                id = R.drawable.cover7;
                break;
            case "Informatique":
                id = R.drawable.cover8;
                break;
            case "Alimentaire":
                id = R.drawable.cover9;
                break;
            case "Métallurgie":
                id = R.drawable.cover10;
                break;
            case "Médical":
                id = R.drawable.cover11;
                break;
            case "Nautisme":
                id = R.drawable.cover12;
                break;
            case "Paramédical":
                id = R.drawable.cover13;
                break;
            case "Restauration":
                id = R.drawable.cover14;
                break;
            case "Sécurité":
                id = R.drawable.cover15;
                break;
            case "Textile":
                id = R.drawable.cover16;
                break;
            case "Tourisme":
                id = R.drawable.cover17;
                break;
            case "Transport":
                id = R.drawable.cover18;
                break;
            default:
                id = R.drawable.cover19;
                break;
        }
        return id;
    }

    public void initView() {
        recyclerView = findViewById(R.id.main_recycler_view);
        spinner = findViewById(R.id.main_spinner);
        layoutEmpty = findViewById(R.id.main_linear_layout);

//        appBarLayout = findViewById(R.id.app_bar_main);
    }

    private void getActivities(String activity_area) {
        commerces = new ArrayList<>();
        // va chercher dans la bd , la table "commerce"
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Commerce");
        ParseQuery<ParseObject> queryImg = ParseQuery.getQuery("Commerce_Photos");
        // requete qui me cherche toutes les valeurs avec "nomCommerce" et "nombrePartages"
        query.selectKeys(Arrays.asList("nomCommerce", "nombrePartages", "thumbnailPrincipal")).whereEqualTo("typeCommerce", activity_area);
        List<ParseObject> results = null;

        try {
            // le resusltat de la requete qui précède se trouve dans  resulats
            results = query.find();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < Objects.requireNonNull(results).size(); i++) {
            String imgId = results.get(i).getParseObject("thumbnailPrincipal").getObjectId();
            if (imgId != null) {
                queryImg.whereEqualTo("objectId", imgId);
            }
            List<ParseObject> image = null;
            try {
                image = queryImg.find();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            //assert image != null;
            commerces.add(new Commerce(results.get(i).getString("nomCommerce"), results.get(i).getInt("nombrePartages"), image.get(0).getParseFile("photo").getUrl()));
        }

//        adapter.notifyDataSetChanged();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        final LinearLayout layout = findViewById(R.id.ll_menu);

        final MenuItem searchItem = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.setVisibility(View.INVISIBLE);
            }
        });

        ImageView closeButton = searchView.findViewById(R.id.search_close_btn);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = findViewById(R.id.search_src_text);
                editText.setText("");
                searchView.setQuery("", false);
                searchView.onActionViewCollapsed();
                layout.setVisibility(View.VISIBLE);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() != 0) {
                    // TODO Adaptor
                    adapter = new CommerceAdapter(MainActivity.this, rechercher(newText), recyclerView);
                    recyclerView.setAdapter(adapter);
                } else {
                    adapter = new CommerceAdapter(MainActivity.this, commerces, recyclerView);
                    recyclerView.setAdapter(adapter);
                }
                return true;
            }
        });

        return true;
    }

    public List<Commerce> rechercher(String charString) {
        ArrayList<Commerce> myFilter = new ArrayList<>();
        if (charString.isEmpty()) {
            myFilter = commerces;
        } else {
            for (int i = 0; i < commerces.size(); i++) {
                /*if (commerces.get(i).getName().toLowerCase().contains(charString)) {
                    myFilter.add(commerces.get(i));
                }*/
            }
        }
        return myFilter;
    }
























































































    /**
     * RecyclerView item decoration - give equal margin around grid item
     */
    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount; // item column

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
                outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)

                if (position < spanCount) { // top edge
                    outRect.top = spacing;
                }
                outRect.bottom = spacing; // item bottom
            } else {
                outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
                outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
                if (position >= spanCount) {
                    outRect.top = spacing; // item top
                }
            }
        }
    }

    /**
     * Converting dp to pixel
     */
    private int dpToPx() {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5, r.getDisplayMetrics()));
    }
}
