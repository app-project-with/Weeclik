package com.grace.weeclik;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.grace.weeclik.adapter.ViewPagerAdapter;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

public class DetailsActivity extends AppCompatActivity {

    ParseUser commerce = ParseUser.getCurrentUser();    // commerce est un utilisateur
    ParseQuery<ParseObject> query = ParseQuery.getQuery("Commerce");


    String nameCommerce;
    int nbShareCommerce;
    String typeCommerce;
    String addressCommerce;
    String webSiteCommerce;
    String descriptionCommerce;

    private TextView name;
    private TextView nbShare;
    private TextView type;
    private TextView address;
    private TextView webSite;
    private TextView description;

    private ViewPager viewPager;
    private ImageButton imageButton_back;
    ImageButton image_button_call;
    ImageButton image_button_location;
    ImageButton image_button_website;
    Button image_button_share;


    int NB_IMG_IN_VIEW_PAGER = 4;
    int currentPage = 0;
    Timer timer;
    final long DELAY_MS = 500;
    final long PERIOD_MS = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        getDataFromMain();

        query.selectKeys(Arrays.asList("nomCommerce", "siteWeb", "adresse", "promotions", "mail", "tel", "description"))
                .whereContains("nomCommerce", nameCommerce);
        List<ParseObject> results = null;


        initView();

        autoSwipe();


    }

    public void initView() {

        name = findViewById(R.id.tv_name_detail);
        name.setText(nameCommerce);

        Resources resources = getResources();
        String nb = resources.getQuantityString(R.plurals.numberOfShare, nbShareCommerce, nbShareCommerce);

        nbShare = findViewById(R.id.tv_nb_share_detail);
        nbShare.setText(nb/*String.valueOf(nbShareCommerce)*/);

        image_button_call = findViewById(R.id.ib_call);
        image_button_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionCall();
            }
        });

        image_button_location = findViewById(R.id.ib_location);
        image_button_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionLocation();
            }
        });

        image_button_website = findViewById(R.id.ib_website);
        image_button_website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionWebsite();
            }
        });

        image_button_share = findViewById(R.id.ib_share);
        image_button_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionShare();
            }
        });

        imageButton_back = findViewById(R.id.ib_back_home);
        imageButton_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        viewPager = findViewById(R.id.vp_details);
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this);
        viewPager.setAdapter(viewPagerAdapter);

        TabLayout tabLayout = findViewById(R.id.tl_details);
        tabLayout.setupWithViewPager(viewPager, true);
    }

    public void autoSwipe() {
        // DONE : utiliser le timer apres avoir demarrer le DetailsActivity
        final Handler handler = new Handler();
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                if (currentPage == NB_IMG_IN_VIEW_PAGER - 1) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
            }
        };
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(update);
            }
        }, DELAY_MS, PERIOD_MS);
    }

    public void getDataFromMain() {
        nameCommerce = Objects.requireNonNull(getIntent().getExtras()).getString("NAME_TRADE");
        nbShareCommerce = Objects.requireNonNull(getIntent().getExtras()).getInt("NBSHARE_TRADE");
        typeCommerce = Objects.requireNonNull(getIntent().getExtras()).getString("TYPE_TRADE");
        addressCommerce = Objects.requireNonNull(getIntent().getExtras()).getString("ADDRESS_TRADE");
        webSiteCommerce = Objects.requireNonNull(getIntent().getExtras()).getString("WEBSITE_TRADE");
        descriptionCommerce = Objects.requireNonNull(getIntent().getExtras()).getString("DESCRIPTION_TRADE");
    }

    /*@Override
    public void onBackPressed() {
        //moveTaskToBack(true);
        Intent backMain = new Intent(Intent.ACTION_MAIN);
        backMain.addCategory(Intent.CATEGORY_HOME);
        backMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(backMain);
    }*/

    private void actionCall() {
        Intent intent_call = new Intent(Intent.ACTION_CALL);
        intent_call.setData(Uri.parse("tel:"/*TODO add phone nomber*/));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.

            if (ActivityCompat.shouldShowRequestPermissionRationale(DetailsActivity.this, Manifest.permission.CALL_PHONE)) {

            } else {
                ActivityCompat.requestPermissions(DetailsActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 1);
            }

            return;
        }
        startActivity(intent_call);
    }

    private void actionLocation() {
        Animation animation = AnimationUtils.loadAnimation(DetailsActivity.this, R.anim.bounce);
        image_button_location.startAnimation(animation);
    }

    private void actionWebsite() {
        Animation animation = AnimationUtils.loadAnimation(DetailsActivity.this, R.anim.bounce);
        image_button_website.startAnimation(animation);
    }

    private void actionShare() {
        Animation animation = AnimationUtils.loadAnimation(DetailsActivity.this, R.anim.bounce);
        image_button_share.startAnimation(animation);
    }
}
