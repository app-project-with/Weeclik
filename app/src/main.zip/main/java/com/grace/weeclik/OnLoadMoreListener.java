package com.grace.weeclik;

/**
 * PACKAGE_NAME
 * Created by grace on 30/05/2018.
 */
public interface OnLoadMoreListener {
    void onLoadMore();
}
